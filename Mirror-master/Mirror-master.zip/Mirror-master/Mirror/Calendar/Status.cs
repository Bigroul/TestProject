﻿

namespace Mirror.Calendar
{
    public enum Status
    {
        Tentative,
        Confirmed,
        Cancelled
    };
}